using Terraria.ModLoader;

namespace TERRARIATALE
{
	class TERRARIATALE : Mod
	{
		public TERRARIATALE()
		{
		}
	}
}
